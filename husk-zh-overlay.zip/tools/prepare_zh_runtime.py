#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Stage unmodified native dependencies from the matching official 2.0 release.

The app and both extensions are rebuilt from source. QEMU, ANGLE, MoltenVK
and the Android runtime are unchanged upstream artifacts, not recompiled here.
"""
import hashlib
import pathlib
import shutil
import urllib.request
import zipfile

root = pathlib.Path(__file__).resolve().parents[1]
archive = root / 'build/Husk-official-2.0.ipa'
archive.parent.mkdir(exist_ok=True)
if not archive.exists():
    urllib.request.urlretrieve('https://github.com/Leviidev/Husk/releases/download/2.0/Husk.ipa', archive)
expected = '55ca8a6a8a9194759be578ef340553372a4427257093c659d5dc3b2971d722e7'
actual = hashlib.sha256(archive.read_bytes()).hexdigest()
if actual != expected:
    raise SystemExit(f'Official IPA SHA256 mismatch: {actual}')
with zipfile.ZipFile(archive) as package:
    if package.testzip() is not None:
        raise SystemExit('Official IPA failed CRC validation')
    package.extractall(root / 'build/official')
app = root / 'build/official/Payload/Husk.app'
lib = root / 'build/ios-arm64/lib'
lib.mkdir(parents=True, exist_ok=True)
shutil.copy2(app / 'Frameworks/libqemu-aarch64-softmmu.dylib', lib)
shutil.copytree(app / 'Frameworks/MoltenVK.framework', lib / 'MoltenVK.framework', dirs_exist_ok=True)
angle = root / 'build/ios-arm64/sysroot/lib'
angle.mkdir(parents=True, exist_ok=True)
shutil.copy2(app / 'Frameworks/libANGLE-shared.dylib', angle)

project = root / 'src/app/project.yml'
text = project.read_text()
text = text.replace('../../build/ios-arm64/lib/MoltenVK.xcframework', '../../build/ios-arm64/lib/MoltenVK.framework')
start = text.index('    preBuildScripts:')
end = text.index('    postBuildScripts:', start)
text = text[:start] + '''    preBuildScripts:
      - name: Stage official 2.0 Android runtime resources
        script: |
          set -euo pipefail
          SRC="$SRCROOT/../../build/official/Payload/Husk.app/"
          DST="$BUILT_PRODUCTS_DIR/$UNLOCALIZED_RESOURCES_FOLDER_PATH/"
          mkdir -p "$DST"
          rsync -a --exclude Husk --exclude Info.plist --exclude PkgInfo \\
            --exclude Frameworks --exclude PlugIns --exclude _CodeSignature \\
            --exclude embedded.mobileprovision --exclude Assets.car \\
            --exclude default.metallib --exclude '*.png' "$SRC" "$DST"
        basedOnDependencyAnalysis: false

''' + text[end:]
# Widget uses the same Chinese dictionary for status labels.
needle = '      - path: Shared\n    settings:'
assert needle in text
text = text.replace(needle, '      - path: Shared\n      - path: Husk/Resources/husk-zh-Hans.json\n        buildPhase: resources\n    settings:')
project.write_text(text)
print('Staged verified official 2.0 runtime:', actual)
