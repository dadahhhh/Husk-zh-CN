// SPDX-License-Identifier: GPL-2.0-or-later
import SwiftUI

/// The FAQ tab: common problems and what to do about them, so a user stuck on JIT or on an app
/// that will not open has an answer without leaving Husk.
struct FAQTab: View {
    @State private var query = ""

    private var sections: [FAQ.Section] {
        let q = query.trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { return FAQ.sections }
        return FAQ.sections.compactMap { s in
            let items = s.items.filter { $0.question.localizedCaseInsensitiveContains(q) || $0.answer.localizedCaseInsensitiveContains(q) }
            return items.isEmpty ? nil : FAQ.Section(title: s.title, symbol: s.symbol, items: items)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(sections) { s in
                    Section {
                        ForEach(s.items) { item in FAQRow(item: item, expanded: !query.isEmpty) }
                    } header: {
                        Label(HuskL10n.text(s.title), systemImage: s.symbol)
                    }
                }
                if sections.isEmpty {
                    Text(HuskL10n.text("Nothing matches “\(query)”. Open Settings › About › Open Console to see what Husk is doing."))
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle(HuskL10n.text("FAQ"))
            .searchable(text: $query, prompt: "Search problems")
        }
    }
}

private struct FAQRow: View {
    let item: FAQ.Item
    var expanded: Bool
    @State private var open = false

    var body: some View {
        DisclosureGroup(isExpanded: Binding(get: { open || expanded }, set: { open = $0 })) {
            Text(.init(HuskL10n.text(item.answer)))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.vertical, 4)
        } label: {
            Text(HuskL10n.text(item.question)).font(.body.weight(.medium))
        }
    }
}

enum FAQ {
    struct Item: Identifiable { let question: String; let answer: String; var id: String { question } }
    struct Section: Identifiable { let title: String; let symbol: String; let items: [Item]; var id: String { title } }

    static let sections: [Section] = [
        Section(title: "JIT", symbol: "bolt.fill", items: [
            Item(question: "什么是 JIT，Husk 为什么需要它？",
                 answer: "安卓应用和游戏需要在运行时编译代码，因此需要可写入并可执行的内存。iOS 仅在调试器连接到应用时允许这样做。开启 JIT 会短暂连接调试器。没有 JIT，Husk 可以显示应用库，但无法启动安卓系统或游戏。"),
            Item(question: "应该选择哪种方式开启 JIT？",
                 answer: "• **iOS 27 及以上：**设置 › JIT › 在此 iPhone 上配对，无需电脑。\n• **iOS 26：**使用内置 StikJIT、电脑生成的配对文件以及 LocalDevVPN。\n• **较早的 iOS，或在 LiveContainer 中运行 Husk：**使用 StikDebug。\n• **通过 TrollStore 安装：**使用 TrollStore，并开启其 URL Scheme 设置。\n• **通过 Dopamine 越狱：**在越狱设置中为应用开启 JIT。"),
            Item(question: "StikJIT 无法连接，或开启 JIT 失败",
                 answer: "1. 确认已安装并连接 **LocalDevVPN**，状态栏应显示 VPN 图标。\n2. 即使数据不会离开 iPhone，也必须开启 Wi-Fi。\n3. 必须开启**开发者模式**（设置 › 隐私与安全性 › 开发者模式）。\n4. 首次使用时 Husk 会下载 Apple 开发者磁盘映像，可能需要等待片刻，请让下载完成。\n5. 仍然失败时，请重新开关 LocalDevVPN，再次配对。"),
            Item(question: "开发者模式中没有出现“与 Husk 配对”",
                 answer: "先在 Husk 中轻点**开始配对**，并在提示时允许访问**本地网络**。如果之前拒绝过，请前往“设置 › 隐私与安全性 › 本地网络 › Husk”开启。必须开启 Wi-Fi。还需要提前开启开发者模式，首次开启时 iPhone 会重新启动。"),
            Item(question: "配对文件失效了",
                 answer: "重置 iPhone 的信任设置后，配对文件会失效；部分 iOS 更新也可能导致失效。请生成新文件，或在 iOS 27 上直接用 iPhone 重新配对，然后在“设置 › JIT”中重新导入。"),
            Item(question: "StikDebug 已打开，但 JIT 仍未开启",
                 answer: "单独打开 StikDebug，确认已经导入配对文件，并已连接 LocalDevVPN。请将 StikDebug 更新到最新版本。Husk 会自动向 StikDebug 发送脚本，无需在 StikDebug 内为 Husk 另行配置。"),
            Item(question: "为什么需要反复开启 JIT？",
                 answer: "JIT 仅在 Husk 持续运行期间有效。当 iOS 在后台关闭 Husk，或你将它从后台划掉后，下次打开都需要重新开启 JIT。使用本机配对或配对文件后，只需轻点一次即可开启。"),
            Item(question: "不开启 JIT 能使用 Husk 吗？",
                 answer: "可以浏览和导入应用，但无法运行安卓内容。所有游戏和应用均需要 JIT。"),
        ]),
        Section(title: "Husk 本身", symbol: "app.badge", items: [
            Item(question: "Husk 完全无法打开",
                 answer: "• **打开后立即退出：**签名证书可能已经过期。免费 Apple 账号的签名通常有效 7 天。请使用侧载工具重新签名或覆盖安装 Husk，应用和存档会保留。\n• **提示“不受信任的开发者”：**请前往“设置 › 通用 › VPN 与设备管理”信任证书。\n• **要求开启开发者模式：**请在“设置 › 隐私与安全性”中开启。"),
            Item(question: "游玩时 Husk 退出了",
                 answer: "重新打开 Husk 后，会显示退出原因，并提供可以分享的报告。通常是游戏内存不足，或遇到了 Husk 暂不支持的功能。请关闭其他应用；如果问题反复出现，请分享报告。"),
            Item(question: "如何获取日志来报告问题？",
                 answer: "在应用库中打开应用详情，轻点**分享报告**。如需 Husk 自身的日志，请前往“设置 › 关于 › **打开控制台**”。在那里开启**开发者信息**可显示更多细节。"),
            Item(question: "如何更新 Husk？",
                 answer: "有新版本时 Husk 会提示你。请用相同的侧载工具将新版 IPA 覆盖安装到旧版上，应用库、应用及存档会保留。"),
        ]),
        Section(title: "应用与游戏", symbol: "gamecontroller.fill", items: [
            Item(question: "应用无法打开",
                 answer: "打开应用库中的应用详情，Husk 会说明停止原因：\n• **受保护的应用：**应用会检查是否运行于真实安卓手机，或使用反作弊、DRM。Husk 不会绕过这些保护。\n• **CPU 代码类型不匹配：**APK 只有 32 位代码，请寻找 arm64（arm64-v8a）版本。\n• **应用不完整或缺少游戏数据：**APK 需要拆分文件或 OBB，请导入完整的 .apks、.xapk 或 .apkm。\n• **需要 Google：**应用依赖 Husk 无法提供的 Google 账号或 Play 服务。\n• **使用了 Husk 暂不支持的功能：**请分享报告，以便后续完善。"),
            Item(question: "屏幕一直黑屏",
                 answer: "大型游戏首次启动时需要准备代码和数据，可能耗时一分钟。如果之后仍然黑屏，请关闭并重新打开一次；仍无变化时，请分享报告。"),
            Item(question: "修改版或重新打包的 APK 崩溃",
                 answer: "APKVISION 等网站的重打包版本可能会把应用代码封装到自己的库中，或添加防篡改检查，因此更容易出错。请尝试开发者提供的原版 APK，或 APKMirror 上的原版。"),
            Item(question: "可以导入哪些文件？",
                 answer: "支持 .apk，以及 .apks、.xapk、.apkm 格式的拆分安装包。可以分享到 Husk、从“文件”中打开，或轻点应用库中的 + 号导入。"),
            Item(question: "游戏运行缓慢或手机发热",
                 answer: "请关闭其他应用，并让手机降温。虽然游戏以原生代码运行，但部分原本由安卓手机硬件完成的工作，需要由 CPU 处理。低电量模式也会降低 Husk 的运行速度。"),
            Item(question: "可以使用手柄吗？",
                 answer: "可以。在 iPhone 的蓝牙设置中连接手柄后，支持手柄的游戏就能识别它。"),
            Item(question: "游戏运行时可以继续使用 Husk 吗？",
                 answer: "在设置中开启**在窗口中打开应用**。之后应用会在可移动、调整大小及最小化的窗口中打开。"),
            Item(question: "无法使用 Google 登录",
                 answer: "Husk 不包含 Google Play 服务，因此应用中的“使用 Google 登录”按钮可能无法工作。如果应用支持，请改用邮箱或其他登录方式。"),
        ]),
        Section(title: "存档与存储", symbol: "externaldrive.fill", items: [
            Item(question: "我的存档在哪里？",
                 answer: "各个应用的数据保存在 Husk 内。可在应用详情中使用**备份存档**导出数据，再用**恢复存档**导入，也可以恢复到另一台 iPhone。"),
            Item(question: "Husk 占用了很多存储空间",
                 answer: "导入的应用及其数据保存在 Husk 文件夹中。可在游戏详情中移除不再游玩的游戏。完整安卓系统还需要额外下载约 2 GB，仅在使用安卓系统本身时才需要。"),
        ]),
        Section(title: "Android", symbol: "cpu", items: [
            Item(question: "应用运行模式和安卓系统有什么区别？",
                 answer: "大多数应用和游戏可以像原生应用一样，直接在 iPhone 上运行。完整安卓系统是另一种较慢的运行方式，用于只能在真实安卓环境中运行的内容。"),
            Item(question: "安卓系统启动很慢",
                 answer: "首次启动需要下载安卓镜像并进行冷启动，可能耗时数分钟。之后 Husk 会恢复已保存的虚拟机，速度会快很多。"),
        ]),
    ]
}
