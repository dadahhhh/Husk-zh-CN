// SPDX-License-Identifier: GPL-2.0-or-later
import Foundation

/// Localizes String-valued SwiftUI content as well as literal titles.
/// Unknown content (including game names and diagnostics) passes through.
enum HuskL10n {
    private static let translations: [String: String] = {
        guard let url = Bundle.main.url(forResource: "husk-zh-Hans", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let table = try? JSONDecoder().decode([String: String].self, from: data)
        else { return [:] }
        return table
    }()

    private struct Template {
        let expression: NSRegularExpression
        let translated: String
        let arguments: [Int]
    }

    private static let token = try! NSRegularExpression(pattern: #"%(?:(\d+)\$)?(?:@|lld|ld|llu|lu|d|u|f|g)"#)
    private static let templates: [Template] = translations.keys.sorted {
        $0.count > $1.count
    }.compactMap { source in
        guard source.unicodeScalars.filter({ CharacterSet.letters.contains($0) }).count >= 6 else { return nil }
        let ns = source as NSString
        let matches = token.matches(in: source, range: NSRange(location: 0, length: ns.length))
        guard !matches.isEmpty, let translated = translations[source] else { return nil }
        var pattern = "^"
        var offset = 0
        var arguments: [Int] = []
        for (index, match) in matches.enumerated() {
            pattern += NSRegularExpression.escapedPattern(for: ns.substring(with: NSRange(location: offset, length: match.range.location - offset)))
            pattern += "([\\s\\S]*?)"
            arguments.append(match.range(at: 1).location == NSNotFound ? index + 1 : Int(ns.substring(with: match.range(at: 1))) ?? index + 1)
            offset = NSMaxRange(match.range)
        }
        pattern += NSRegularExpression.escapedPattern(for: ns.substring(from: offset)) + "$"
        guard let expression = try? NSRegularExpression(pattern: pattern) else { return nil }
        return Template(expression: expression, translated: translated, arguments: arguments)
    }

    static func text(_ source: String) -> String {
        if let translated = translations[source] { return translated }
        // Avoid matching entire logs or downloaded descriptions against UI templates.
        guard source.utf16.count < 2048 else { return source }
        let ns = source as NSString
        let range = NSRange(location: 0, length: ns.length)
        for template in templates {
            guard let match = template.expression.firstMatch(in: source, range: range) else { continue }
            var values: [Int: String] = [:]
            for (index, argument) in template.arguments.enumerated() {
                values[argument] = ns.substring(with: match.range(at: index + 1))
            }
            let output = template.translated as NSString
            let placeholders = token.matches(in: template.translated, range: NSRange(location: 0, length: output.length))
            var result = template.translated
            for (index, placeholder) in placeholders.enumerated().reversed() {
                let position = placeholder.range(at: 1).location == NSNotFound ? index + 1 : Int(output.substring(with: placeholder.range(at: 1))) ?? index + 1
                guard let value = values[position], let swiftRange = Range(placeholder.range, in: result) else { continue }
                result.replaceSubrange(swiftRange, with: value)
            }
            return result
        }
        return source
    }
}
